"""
app.py

Streamlit front-end for real-time facial emotion recognition.
Run with:
    streamlit run app.py

Uses streamlit-webrtc for continuous browser-webcam access (works over
the network / when deployed, unlike a raw cv2.VideoCapture loop which
only works on the machine Streamlit itself is running on).
"""

import os
import time
from collections import Counter, deque

import av
import numpy as np
import pandas as pd
import streamlit as st
from streamlit_webrtc import RTCConfiguration, WebRtcMode, webrtc_streamer
from tensorflow.keras.models import load_model

from utils.emotion_labels import EMOTION_EMOJIS, EMOTIONS
from utils.preprocessing import detect_faces, draw_result, preprocess_face

# ----------------------------- Page setup -----------------------------
st.set_page_config(page_title="Emotion AI", page_icon="🧠", layout="wide")

MODEL_PATH = os.path.join(os.path.dirname(__file__), "model", "emotion_model.keras")

if "history" not in st.session_state:
    st.session_state.history = deque(maxlen=50)  # (timestamp, label, confidence)


@st.cache_resource
def get_model():
    if not os.path.exists(MODEL_PATH):
        return None
    return load_model(MODEL_PATH)


model = get_model()

# ----------------------------- Header -----------------------------
st.markdown("## 🧠 Emotion AI")
st.markdown("##### Real-Time Facial Emotion Recognition — Powered by Deep Learning")

if model is None:
    st.warning(
        f"No trained model found at `model/emotion_model.keras`. "
        f"Run `python training/train_model.py` first, then reload this page."
    )

tab_live, tab_perf, tab_about = st.tabs(["🎥 Live Detection", "📊 Model Performance", "ℹ️ About"])

# ----------------------------- Live Detection tab -----------------------------
with tab_live:
    col_cam, col_result = st.columns([2, 1])

    latest_probs = {"probs": np.zeros(len(EMOTIONS))}

    def video_frame_callback(frame: av.VideoFrame) -> av.VideoFrame:
        img = frame.to_ndarray(format="bgr24")

        if model is not None:
            faces = detect_faces(img)
            if len(faces) > 0:
                box = faces[0]
                tensor = preprocess_face(img, box)
                probs = model.predict(tensor, verbose=0)[0]
                latest_probs["probs"] = probs

                idx = int(np.argmax(probs))
                label = EMOTIONS[idx]
                confidence = float(probs[idx])

                draw_result(img, box, label, confidence)
                st.session_state.history.append((time.strftime("%H:%M:%S"), label, confidence))

        return av.VideoFrame.from_ndarray(img, format="bgr24")

    with col_cam:
        webrtc_streamer(
            key="emotion-detect",
            mode=WebRtcMode.SENDRECV,
            rtc_configuration=RTCConfiguration(
                {"iceServers": [{"urls": ["stun:stun.l.google.com:19302"]}]}
            ),
            video_frame_callback=video_frame_callback,
            media_stream_constraints={"video": True, "audio": False},
        )

    with col_result:
        st.markdown("#### Detected Emotion")
        if st.session_state.history:
            _, last_label, last_conf = st.session_state.history[-1]
            st.markdown(f"# {EMOTION_EMOJIS[last_label]} {last_label.upper()}")
            st.markdown(f"**Confidence:** {last_conf * 100:.1f}%")
        else:
            st.markdown("# — waiting —")

        st.markdown("#### Probability Breakdown")
        probs_df = pd.DataFrame(
            {"Emotion": EMOTIONS, "Probability": latest_probs["probs"]}
        ).sort_values("Probability", ascending=False)
        st.bar_chart(probs_df.set_index("Emotion"))

    st.markdown("---")
    col_hist, col_stats = st.columns(2)

    with col_hist:
        st.markdown("#### Detection History (this session)")
        if st.session_state.history:
            hist_df = pd.DataFrame(
                reversed(st.session_state.history), columns=["Time", "Emotion", "Confidence"]
            )
            hist_df["Confidence"] = (hist_df["Confidence"] * 100).round(1).astype(str) + "%"
            st.dataframe(hist_df, hide_index=True, use_container_width=True)
        else:
            st.caption("No detections yet — start the camera above.")

    with col_stats:
        st.markdown("#### Session Summary")
        if st.session_state.history:
            counts = Counter(label for _, label, _ in st.session_state.history)
            total = sum(counts.values())
            summary_df = pd.DataFrame(
                [{"Emotion": k, "Share": v / total} for k, v in counts.most_common()]
            )
            st.bar_chart(summary_df.set_index("Emotion"))
        else:
            st.caption("Session stats will appear once detections start.")

# ----------------------------- Model Performance tab -----------------------------
with tab_perf:
    st.markdown("#### Training Results")
    results_dir = os.path.join(os.path.dirname(__file__), "results")
    c1, c2 = st.columns(2)
    acc_path = os.path.join(results_dir, "accuracy.png")
    loss_path = os.path.join(results_dir, "loss.png")
    cm_path = os.path.join(results_dir, "confusion_matrix.png")

    if os.path.exists(acc_path):
        c1.image(acc_path, caption="Training vs Validation Accuracy")
    else:
        c1.caption("Run training to generate accuracy.png")

    if os.path.exists(loss_path):
        c2.image(loss_path, caption="Training vs Validation Loss")
    else:
        c2.caption("Run training to generate loss.png")

    if os.path.exists(cm_path):
        st.image(cm_path, caption="Confusion Matrix")
    else:
        st.caption("Run training to generate confusion_matrix.png")

    report_path = os.path.join(results_dir, "classification_report.txt")
    if os.path.exists(report_path):
        st.markdown("#### Classification Report")
        with open(report_path) as f:
            st.code(f.read())

# ----------------------------- About tab -----------------------------
with tab_about:
    st.markdown(
        """
        #### About This Project
        **Dataset:** FER-2013-style, 7 classes (Angry, Disgust, Fear, Happy, Neutral, Sad, Surprise)

        **Model architecture:** 3×(Conv2D → MaxPooling) → Flatten → Dense(128) → Dropout(0.5) → Dense(7, softmax)

        **Technologies:** Python, TensorFlow/Keras, OpenCV, Streamlit, streamlit-webrtc

        **Objective:** Demonstrate real-time facial emotion recognition using a CNN, deployed
        as a lightweight, backend-free web app.

        **Future scope:** larger/more diverse training data, model quantization for faster
        inference, multi-face tracking, deployment to Streamlit Community Cloud.
        """
    )
